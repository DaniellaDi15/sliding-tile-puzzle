﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SlidingTilesPuzzle
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private static readonly int N = 3;
        private static readonly int CARD_SIZE = 120;
        private static readonly int GAP = 1;
        private readonly Color FORGROUND_COLOR = Color.Blue;
        private readonly Color BACKGROUND_COLOR = Color.White;
        private readonly string winMessage = "You are a genius!";
        private Button[,] card = new Button[N, N];

        //defult places
        List<int> icons = new List<int> { 1, 2, 3, 4, 5, 6, 7, 8, 9 };


        private void Form1_Load(object sender, EventArgs e)
        {
            Text = "SlidingTilePuzzle";
            StartPosition = FormStartPosition.CenterScreen;
            int id = 0;

            for (int i = 0; i < N; i++)
            {
                for (int j = 0; j < N; j++)
                {
                    //create botton
                    card[j, i] = new Button
                    {
                        Name = "card" + j + i,
                        Size = new Size(CARD_SIZE, CARD_SIZE),
                        Location = new Point(3 * GAP + j * (CARD_SIZE + GAP), GAP + i * (CARD_SIZE + GAP)),
                        TextAlign = ContentAlignment.MiddleCenter,
                        Font = new Font("Ariel", 40),
                        ForeColor = FORGROUND_COLOR,
                        BackColor = BACKGROUND_COLOR,
                        Text = icons[id].ToString()
                    };

                    Controls.Add(card[j, i]);
                    card[j, i].Click += Button_Click;
                    id++;
                }
            }

            //מתאים את הטופס לגודל התוכן
            AutoSize = true;
            AutoSizeMode = AutoSizeMode.GrowAndShrink;

            // disapear the '9' 
            foreach (Control control in Controls)
            {
                Button button = control as Button;

                if (button.Text == "9")
                {
                    button.Visible = false;
                }
            }

            //mix the cards
            
                Random rnd = new Random();
                int emptyX = N - 1, emptyY = N - 1;

                for (int k = 0; k < 100; k++)
                {
                    List<Point> nList = getNeighbors(emptyX, emptyY);

                    //choose nighbor to exchange
                    int n = rnd.Next(nList.Count);
                    Point Pchoosed = nList[n];
                    string temp = card[emptyX, emptyY].Text;

                    card[emptyX, emptyY].Text = card[Pchoosed.X, Pchoosed.Y].Text;
                    card[emptyX, emptyY].Visible = true;
                    card[emptyX, emptyY].Focus();
                    card[Pchoosed.X, Pchoosed.Y].Text = temp;
                    card[Pchoosed.X, Pchoosed.Y].Visible = false;
                    emptyX = Pchoosed.X;
                    emptyY = Pchoosed.Y;

                    //check if win 
                    if (complete(false))
                    {
                        k = 0;
                    }
                }
            }
        
        //get list of neighbors 
        private List<Point> getNeighbors(int emptyX, int emptyY)
        {
            List<Point> result = new List<Point>();

            if ((emptyX - 1) >= 0)    //left
                result.Add(new Point((emptyX - 1), emptyY));
            if ((emptyX + 1) < N)     //right
                result.Add(new Point((emptyX + 1), emptyY));
            if ((emptyY - 1) >= 0)    //down
                result.Add(new Point((emptyX), emptyY - 1));
            if ((emptyY + 1) < N)     //up
                result.Add(new Point((emptyX), emptyY + 1));

            return result;
        }

        private void Button_Click(object sender, EventArgs e)
        {
            
                Swap(sender, e);
        }

        private void Swap(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            int newX = 0, newY = 0, emptyX = 0, emptyY = 0;

            for (int i = 0; i < N; i++)
            {
                for (int j = 0; j < N; j++)
                {
                    //find clicked card loction
                    if (btn == card[i, j])
                    {
                        newX = i;
                        newY = j;
                    }

                    // '9' card
                    if (card[i, j].Visible == false)
                    {
                        emptyX = i;
                        emptyY = j;
                    }
                }
            }

            string temp = card[emptyX, emptyY].Text;

            //left or right
            if ((emptyX - newX == 1 && emptyY == newY || (newX - emptyX == 1 && emptyY == newY)))
            {
                card[emptyX, emptyY].Text = card[newX, newY].Text;
                card[emptyX, emptyY].Visible = true;
                card[emptyX, emptyY].Focus();
                card[newX, newY].Text = temp;
                card[newX, newY].Visible = false;
                complete(true);
            }

            //up or down
            if ((emptyY - newY == 1 && emptyX == newX) || (newY - emptyY == 1 && emptyX == newX))
            {
                card[emptyX, emptyY].Text = card[newX, newY].Text;
                card[emptyX, emptyY].Visible = true;
                card[emptyX, emptyY].Focus();
                card[newX, newY].Text = temp;
                card[newX, newY].Visible = false;
                complete(true);
            }

        }

        //check win
        private bool complete(bool showMessage)
        {
            int index = 1;

            for (int i = 0; i < N; i++)
            {
                for (int j = 0; j < N; j++)
                {
                    if (index == (int.Parse(card[j, i].Text)))
                        index++;
                }
            }

            if (index == 10 && card[N - 1, N - 1].Visible == false)
            {
                if (showMessage)
                {
                    MessageBox.Show(winMessage);

                    //lock the buttons
                    foreach (Control control in Controls)
                    {
                        Button button = control as Button;
                        button.Enabled = false;
                    }
                    return true;
                }

            }

            return false;
        }
    }
}

